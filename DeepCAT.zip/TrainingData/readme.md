The training data contains 4 files:

Tumor training and testing data are TCRs called by TRUST2.4 from TCGA data.

Normal control sequences are obtained from healthy donors' (Emerson 2017 Nature Genetics) TCR sequencing data. 
