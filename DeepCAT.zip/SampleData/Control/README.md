This folder contains the top 10,000 most abundant TCRs from 30 non-cancer healthy individuals (Emerson 2017 cohort).
