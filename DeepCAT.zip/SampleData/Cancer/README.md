This folder contains the top 10,000 most abundant TCRs from 16 early-stage breast cancer patients (Beausang et al., 2017, PNAS).
